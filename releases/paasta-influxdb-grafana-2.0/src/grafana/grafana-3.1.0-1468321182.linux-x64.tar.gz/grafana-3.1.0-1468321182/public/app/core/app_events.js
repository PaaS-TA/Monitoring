/*! grafana - v3.1.0-1468321182 - 2016-07-12
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./utils/emitter"],function(a){var b,c;return{setters:[function(a){b=a}],execute:function(){c=new b.Emitter,a("default",c)}}});
declare var template: string;
export default template;

/// <reference path="../../../../../public/app/headers/common.d.ts" />
import TableModel from '../../../core/table_model';
declare var transformers: {};
declare function transformDataToTable(data: any, panel: any): TableModel;
export { transformers, transformDataToTable };

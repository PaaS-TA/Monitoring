/// <reference path="../../../../../public/app/headers/common.d.ts" />
export declare class ConfigCtrl {
    private backendSrv;
    static template: string;
    appEditCtrl: any;
    /** @ngInject **/
    constructor(backendSrv: any);
    initDatasource(): any;
}

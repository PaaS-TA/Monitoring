/// <reference path="../../../../../public/app/headers/common.d.ts" />
import { PanelCtrl } from 'app/plugins/sdk';
export declare class UnknownPanelCtrl extends PanelCtrl {
    static templateUrl: string;
    /** @ngInject */
    constructor($scope: any, $injector: any);
}

///<reference path="../../../headers/common.d.ts" />

import angular from 'angular';
import {MixedDatasource} from './datasource';

export {MixedDatasource, MixedDatasource as Datasource};


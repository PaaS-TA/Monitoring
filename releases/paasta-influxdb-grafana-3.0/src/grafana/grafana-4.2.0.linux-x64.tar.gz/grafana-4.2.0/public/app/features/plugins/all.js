/*! grafana - v4.2.0 - 2017-03-22
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./plugin_edit_ctrl","./plugin_page_ctrl","./plugin_list_ctrl","./import_list/import_list","./ds_edit_ctrl","./ds_list_ctrl"],function(a,b){"use strict";b&&b.id;return{setters:[function(a){},function(a){},function(a){},function(a){},function(a){},function(a){}],execute:function(){}}});
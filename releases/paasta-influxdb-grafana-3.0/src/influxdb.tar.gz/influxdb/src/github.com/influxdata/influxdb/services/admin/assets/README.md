Please note that these files are embedded into the `influxd` binary using the
[statik](https://github.com/rakyll/statik) tool. `go generate` needs to be run
whenever there are changes made to files in this directory. See the admin
interface readme for more information.

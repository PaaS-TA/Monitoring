// Copyright (c) 2016 Uber Technologies, Inc.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

package zap

import (
	"bytes"
	"flag"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestLevelEnablerFunc(t *testing.T) {
	opts := []Option{Fields(Int("foo", 42)), LevelEnablerFunc(func(l Level) bool { return l == DebugLevel })}
	withJSONLogger(t, opts, func(log Logger, buf *testBuffer) {
		log.Debug("@debug", Int("logger", 0))
		log.Info("@info", Int("logger", 0))
		assert.Equal(t, []string{
			`{"level":"debug","msg":"@debug","foo":42,"logger":0}`,
		}, buf.Lines())
	})
}

func TestLevelString(t *testing.T) {
	tests := map[Level]string{
		DebugLevel:  "debug",
		InfoLevel:   "info",
		WarnLevel:   "warn",
		ErrorLevel:  "error",
		DPanicLevel: "dpanic",
		PanicLevel:  "panic",
		FatalLevel:  "fatal",
		Level(-42):  "Level(-42)",
	}

	for lvl, stringLevel := range tests {
		assert.Equal(t, stringLevel, lvl.String())
	}
}

func TestLevelText(t *testing.T) {
	tests := []struct {
		text  string
		level Level
	}{
		{"debug", DebugLevel},
		{"info", InfoLevel},
		{"warn", WarnLevel},
		{"error", ErrorLevel},
		{"dpanic", DPanicLevel},
		{"panic", PanicLevel},
		{"fatal", FatalLevel},
	}
	for _, tt := range tests {
		lvl := tt.level
		marshaled, err := lvl.MarshalText()
		assert.NoError(t, err, "Unexpected error marshaling level %v to text.", &lvl)
		assert.Equal(t, tt.text, string(marshaled), "Marshaling level %v to text yielded unexpected result.", &lvl)

		var unmarshaled Level
		err = unmarshaled.UnmarshalText([]byte(tt.text))
		assert.NoError(t, err, `Unexpected error unmarshaling text "%v" to level.`, tt.text)
		assert.Equal(t, tt.level, unmarshaled, `Text "%v" unmarshaled to an unexpected level.`, tt.text)
	}
}

func TestLevelNils(t *testing.T) {
	var l *Level

	// The String() method will not handle nil level properly.
	assert.Panics(t, func() {
		assert.Equal(t, "Level(nil)", l.String(), "Unexpected result stringifying nil *Level.")
	}, "Level(nil).String() should panic")

	_, err := l.MarshalText()
	assert.Equal(t, errMarshalNilLevel, err, "Expected errMarshalNilLevel.")

	assert.Panics(t, func() {
		var l *Level
		l.UnmarshalText([]byte("debug"))
	}, "Expected to panic when unmarshaling into a null pointer.")
}

func TestLevelUnmarshalUnknownText(t *testing.T) {
	var l Level
	err := l.UnmarshalText([]byte("foo"))
	assert.Contains(t, err.Error(), "unrecognized level", "Expected unmarshaling arbitrary text to fail.")
}

func TestLevelAsFlagValue(t *testing.T) {
	var (
		lvl Level
		buf bytes.Buffer
	)

	fs := flag.NewFlagSet("levelTest", flag.ContinueOnError)
	fs.SetOutput(&buf)
	fs.Var(&lvl, "level", "a log level")

	// changing works
	assert.Equal(t, InfoLevel, lvl)
	assert.NoError(t, fs.Parse([]string{"-level", "warn"}))
	assert.Equal(t, WarnLevel, lvl)
	assert.NoError(t, fs.Parse([]string{"-level", "debug"}))
	assert.Equal(t, DebugLevel, lvl)

	// errors work
	assert.Error(t, fs.Parse([]string{"-level", "nope"}))
	assert.Equal(t,
		`invalid value "nope" for flag -level: unrecognized level: "nope"`,
		strings.Split(buf.String(), "\n")[0],
		"expected error output")
	buf.Reset()
}
